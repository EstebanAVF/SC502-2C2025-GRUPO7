<?php
require 'conexion.php';

$tipo = $_GET['tipo'] ?? '';
$fecha = $_GET['fecha'] ?? '';
$palabra = $_GET['palabra'] ?? '';
$ordenar = $_GET['ordenar'] ?? 'fecha';

$query = "SELECT * FROM eventos WHERE 1=1";

if (!empty($tipo)) {
    $query .= " AND tipo_accidente = ?";
}
if (!empty($fecha)) {
    $query .= " AND DATE(fecha_evento) = ?";
}
if (!empty($palabra)) {
    $query .= " AND descripcion LIKE ?";
}

switch ($ordenar) {
    case 'proximidad':
        $query .= " ORDER BY distancia ASC"; 
        break;
    case 'importancia':
        $query .= " ORDER BY importancia DESC";
        break;
    default:
        $query .= " ORDER BY fecha_evento DESC";
        break;
}

$stmt = $conn->prepare($query);
$params = [];

if (!empty($tipo)) $params[] = $tipo;
if (!empty($fecha)) $params[] = $fecha;
if (!empty($palabra)) $params[] = '%' . $palabra . '%';

$stmt->execute($params);
$resultado = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($resultado);
?>
